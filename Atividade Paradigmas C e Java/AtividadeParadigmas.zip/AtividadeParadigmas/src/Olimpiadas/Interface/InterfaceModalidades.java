package Olimpiadas.Interface;

public interface InterfaceModalidades {
    void participar();

    void calcularVencedor();
}
