package Olimpiadas.Modalidades;

import Olimpiadas.Atletas.AtletaLevantamento;

import java.util.Scanner;

public class LevantamentoPeso implements Olimpiadas.Interface.InterfaceModalidades{

    private AtletaLevantamento[] competidores;

    @Override
    public void participar() {

        Scanner entrada = new Scanner(System.in);
        System.out.println("Digite a quantidade de competidores: ");
        int qtdParticipantes = entrada.nextInt();
        competidores = new AtletaLevantamento[qtdParticipantes];

        for (int i = 0; i < qtdParticipantes; i++) {

            System.out.println("Digite o peso levantado do competidor "+ i + " : ");
            competidores[i].setPesoLevantado(entrada.nextDouble());
        }
        calcularVencedor();
    }

    @Override
    public void calcularVencedor() {
        double maiorPeso = Double.MIN_VALUE;
        int vencedor = 0;

        for (int i = 0; i < competidores.length ; i++) {

            if (competidores[i].getPesoLevantado() > maiorPeso){

                maiorPeso = competidores[i].getPesoLevantado();
                vencedor = i;
            }
        }
        System.out.println("O competidor " + vencedor+1 + " eh o ganhador ");
    }
}
