package Olimpiadas.Modalidades;

import Olimpiadas.Atletas.AtletaArremessoPeso;

import java.util.Scanner;

public class ArremessoPeso implements Olimpiadas.Interface.InterfaceModalidades{

    private AtletaArremessoPeso[] competidores;

    @Override
    public void participar() {

        Scanner entrada = new Scanner(System.in);
        System.out.println("Digite a quantidade de competidores: ");
        int qtdParticipantes = entrada.nextInt();
        competidores = new AtletaArremessoPeso[qtdParticipantes];

        for (int i = 0; i < qtdParticipantes; i++) {

            for (int j = 0; j < 3; j++) {

                System.out.println("Digite a distancia do arremesso "+ j + " : ");
                competidores[i].setArremessos(entrada.nextDouble(),j);
            }
        }
        calcularVencedor();
    }

    @Override
    public void calcularVencedor() {

        int vencedor = -1;
        int vencedorSegundoArremesso = -1;
        int empate = 0;
        double maiorDistancia = Double.MIN_VALUE;
        double segundaMaiorDistancia = Double.MIN_VALUE;

        for (int i = 0; i < competidores.length; i++) {

            for (int j = 0; j < 3; j++) {

                if (competidores[i].getArremessos(j) > maiorDistancia){
                    if (vencedor == i){
                        segundaMaiorDistancia = maiorDistancia;
                    }
                    maiorDistancia = competidores[i].getArremessos(j);
                    vencedor = i;

                }else if (competidores[i].getArremessos(j) == maiorDistancia){
                    empate = 1;
                }else if (competidores[i].getArremessos(j) > segundaMaiorDistancia){
                    segundaMaiorDistancia = competidores[i].getArremessos(j);
                    vencedorSegundoArremesso = i;
                }
            }
        }
        if (empate == 1){
            System.out.println("O competidor " + vencedorSegundoArremesso+1 + " eh o vencedor");
        }else{
            System.out.println("O competidor " + vencedor+1 + " eh o vencedor");
        }
    }
}
