package Olimpiadas.Modalidades;

import Olimpiadas.Atletas.AtletaGinasticaArtistica;

import java.util.Scanner;

public class GinasticaArtistica implements Olimpiadas.Interface.InterfaceModalidades{

    private AtletaGinasticaArtistica [] competidores;

    @Override
    public void participar() {

        Scanner entrada = new Scanner(System.in);
        System.out.println("Digite a quantidade de competidores: ");
        int qtdParticipantes = entrada.nextInt();
        competidores = new AtletaGinasticaArtistica[qtdParticipantes];

        for (int i = 0; i < qtdParticipantes; i++) {

            for (int j = 0; j < 5; j++) {

                System.out.println("Digite a nota "+ j + " : ");
                competidores[i].setNotas(entrada.nextDouble(),j);
            }

        }
        calcularVencedor();
    }

    @Override
    public void calcularVencedor() {

        int vencedor = 0;
        double notaFinal = 0;
        double maiorNota = Double.MIN_VALUE;

        for (int i = 0; i < competidores.length; i++) {

            notaFinal = competidores[i].getNotas(0) + competidores[i].getNotas(1) + competidores[i].getNotas(2) +
                    competidores[i].getNotas(3) + competidores[i].getNotas(4) - competidores[i].getMenorNota();

            if (notaFinal > maiorNota){
                maiorNota = notaFinal;
                vencedor = i;
            }

        }
        System.out.println("O competidor " + vencedor+1 + " eh o vencedor ");
    }
}
