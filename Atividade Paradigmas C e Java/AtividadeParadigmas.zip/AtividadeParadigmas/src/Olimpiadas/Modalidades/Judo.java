package Olimpiadas.Modalidades;

import Olimpiadas.Atletas.AtletaJudo;

import java.util.Scanner;

public class Judo implements Olimpiadas.Interface.InterfaceModalidades{

    private AtletaJudo [] competidores = new AtletaJudo [2];

    @Override
    public void participar() {

        Scanner entrada = new Scanner(System.in);

        for (int i = 0; i < 2; i++) {

            competidores[i] = new AtletaJudo();

            System.out.println("Digite a quantidade de yukos do competidor "+ (i+1) +" : ");
            competidores[i].setYuko(entrada.nextInt());

            System.out.println("Digite a quantidade de wazakis do competidor "+ (i+1) +": ");
            competidores[i].setWazaki(entrada.nextInt());

            System.out.println("Digite a quantidade de ippon do competidor "+ (i+1) +": ");
            competidores[i].setIppon(entrada.nextInt());
        }
        calcularVencedor();
    }

    @Override
    public void calcularVencedor() {

        if (competidores[0].getIppon() > 0){
            System.out.println("O competidor 1 eh o ganhador");

        }else if (competidores[1].getIppon() > 0){
            System.out.println("O competidor 2 eh o ganhador");

        }else if (competidores[0].getWazaki() > 0 && competidores[1].getWazaki() > 0){

            if (competidores[0].getWazaki() > competidores[1].getWazaki()){
                System.out.println("O competidor 1 eh o ganhador");

            }else if (competidores[0].getWazaki() > competidores[1].getWazaki()){
                System.out.println("O competidor 2 eh o ganhador");

            }else if (competidores[0].getYuko() > 0 || competidores[1].getYuko() > 0){

                if (competidores[0].getYuko() > competidores[1].getYuko()){
                    System.out.println("O competidor 1 eh o ganhador");

                }else if (competidores[1].getYuko() > competidores[0].getYuko()){
                    System.out.println("O competidor 2 eh o ganhador");
                }

            }else {
                System.out.println("A luta terminou em um empate");
            }
        }
    }
}
