package Olimpiadas.Atletas;

public class AtletaJudo {

    private int yuko = 0;
    private int wazaki = 0;
    private int ippon = 0;

    public int getYuko() {
        return yuko;
    }

    public void setYuko(int yuko) {
        this.yuko = yuko;
    }

    public int getWazaki() {
        return wazaki;
    }

    public void setWazaki(int wazaki) {
        this.wazaki = wazaki;
    }

    public int getIppon() {
        return ippon;
    }

    public void setIppon(int ippon) {
        this.ippon = ippon;
    }
}
