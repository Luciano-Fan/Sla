package Olimpiadas.Atletas;

public class AtletaGinasticaArtistica {

    private double [] notas = new double [5];
    private double menorNota = Integer.MAX_VALUE;

    public AtletaGinasticaArtistica(){
        for (int i = 0; i < notas.length; i++) {
            this.notas[i] = 0;
        }
    }

    public double getNotas(int i) {
        return this.notas[i];
    }

    public void setNotas(double notas,int i) {
        this.notas[i] = notas;
        if (this.notas[i] < this.menorNota){
            this.menorNota = this.notas[i];
        }
    }

    public double getMenorNota() {
        return this.menorNota;
    }

    public void setMenorNota(double menorNota) {
        this.menorNota = menorNota;
    }
}
