package Olimpiadas.Atletas;

public class AtletaLevantamento {

    private double pesoLevantado = 0;

    public double getPesoLevantado() {
        return this.pesoLevantado;
    }

    public void setPesoLevantado(double pesoLevantado) {
        this.pesoLevantado = pesoLevantado;
    }
}
