package Olimpiadas.Atletas;

public class AtletaArremessoPeso {

    private double [] Arremessos = new double [3];

    public AtletaArremessoPeso (){

        for (int i = 0; i < Arremessos.length; i++) {
            this.Arremessos[i] = 0;
        }
    }

    public double getArremessos(int i) {
        return Arremessos[i];
    }

    public void setArremessos(double arremessos, int i) {
        this.Arremessos[i] = arremessos;
    }
}
