package Olimpiadas;

import Olimpiadas.Modalidades.ArremessoPeso;
import Olimpiadas.Modalidades.GinasticaArtistica;
import Olimpiadas.Modalidades.Judo;
import Olimpiadas.Modalidades.LevantamentoPeso;

import java.util.Scanner;

public class App {

    public static void main(String[] args) {

        ArremessoPeso arremesso = new ArremessoPeso();
        GinasticaArtistica ginastica = new GinasticaArtistica();
        Judo judo = new Judo();
        LevantamentoPeso levantamento = new LevantamentoPeso();
        Scanner entrada = new Scanner(System.in);

        int opcao = -1;

        do {

            System.out.println("Digite a modalidade desejada: \n1- ARREMESSO DE PESO \n2 - GINASTICA ARTISTICA \n3 - JUDO \n4 - LEVANTAMENTO DE PESO \n0 - SAIR\n ");
            opcao = entrada.nextInt();

            switch (opcao) {
                case 1:
                    arremesso.participar();
                    break;
                case 2:
                    ginastica.participar();
                    break;
                case 3:
                    judo.participar();
                    break;
                case 4:
                    levantamento.participar();
                    break;
            }

        }while (opcao != 0);
    }
}
