package applistaencadeada;

public class ListaEncadeada {

    private No inicio;
    private No fim;
    private int qtd;

    public ListaEncadeada() {
        inicio = fim = null;
        qtd = 0;
    }

    public int size() {
        return qtd;
    }

    public boolean isEmpty() {
        return qtd == 0;
    }

    public boolean exist(int elemento) {
        No atual = inicio;
        while (atual != null) {
            if (atual.dado == elemento) {
                return true;
            }
            atual = atual.prox;
        }
        return false;
    }

    public void add(int novoElemento, int posicao) throws Exception {
        if (posicao > qtd) {
            throw new Exception("Posição inválida");
        } else if (posicao == 0 && size() == 0) {
            No novoNo = new No(novoElemento);
            inicio = fim = novoNo;
            qtd++;
        } else if (posicao == 0 && size() > 0) {
            No novoNo = new No(novoElemento);
            novoNo.prox = inicio;
            inicio = novoNo;
            qtd++;
        } else if (posicao == qtd) {
            No novoNo = new No(novoElemento);
            fim.prox = novoNo;
            fim = novoNo;
            qtd++;
        } else {
            No anterior = inicio;
            for (int i = 0; i < posicao - 1; i++) {
                anterior = anterior.prox;
            }
            No novoNo = new No(novoElemento);
            novoNo.prox = anterior.prox;
            anterior.prox = novoNo;
            qtd++;
        }
    }

    public void add(int novoElemento) {
        try {
            add(novoElemento, qtd);
        } catch (Exception e) {
        }
    }

    public int remove(int posicao) throws Exception {
        if (posicao >= qtd) {
            throw new Exception("Posição inválida");
        } else if (isEmpty()) {
            throw new Exception("Lista vazia");
        } else if (posicao == 0 && size() == 1) {
            No removido = inicio;
            inicio = fim = null;
            qtd--;
            return removido.dado;
        } else if (posicao == 0 && size() > 1) {
            No removido = inicio;
            inicio = inicio.prox;
            qtd--;
            return removido.dado;
        } else {
            No anterior = inicio;
            for (int i = 0; i < posicao - 1; i++) {
                anterior = anterior.prox;
            }
            No removido = anterior.prox;
            anterior.prox = removido.prox;
            if (removido == fim) {
                fim = anterior;
            }
            qtd--;
            return removido.dado;
        }
    }

    public void set(int novoValor, int posicao) throws Exception {
        if (posicao > qtd) {
            throw new Exception("Posição inválida");
        } else {
            No atual = inicio;
            for (int i = 0; i < posicao; i++) {
                atual = atual.prox;
            }
            atual.dado = novoValor;
        }
    }

    public int get(int posicao) throws Exception {
        if (posicao > qtd) {
            throw new Exception("Posição inválida");
        } else {
            No atual = inicio;
            for (int i = 0; i < posicao; i++) {
                atual = atual.prox;
            }
            return atual.dado;
        }
    }

    public String ruptura(int elemento) throws Exception {
        int pos = 0;
        ListaEncadeada listaAux = new ListaEncadeada();
        No atual = inicio;

        if (elemento >= qtd || elemento < 0) {
            return null;
        }
        while (atual != null) {
            pos++;
            if (pos > elemento) {
                listaAux.add(atual.dado);
            }
            atual = atual.prox;
        }
        return listaAux.toString();
    }

    public boolean removaNo(int posicao) throws Exception {
        int i = 0;
        if (isEmpty()) {
            throw new Exception("Lista Vazia");

        } else if (posicao > qtd) {
            return false;
        } else {
            while (i < posicao) {

                inicio = inicio.prox;
                qtd--;
                i++;

            }
        }
        return true;
    }

    public void troca(int m, int n) {
        No noM = inicio;
        No noN = inicio;

        for (int i = 0; i < m; i++) {
            noM = noM.prox;
        }

        for (int i = 0; i < n; i++) {
            noN = noN.prox;
        }

        int temp = noN.dado;
        noN.dado = noM.dado;
        noM.dado = temp;
    }

    @Override
    public String toString() {
        String saida = "";
        No atual = inicio;
        while (atual != null) {
            saida += atual.dado + ", ";
            atual = atual.prox;
        }
        return saida;
    }

}
