package exercicio3;

import java.util.Scanner;

public class Exercicio3 {

    public static void main(String[] args) {
        
        Scanner entrada = new Scanner(System.in);
        FilaDinamica f = new FilaDinamica();
        int opcao;
        
        do {
            
            System.out.println("Fila Dinâmica de inteiros");
            System.out.println("Digite:");
            System.out.println("1 - Para inserir um elemento");
            System.out.println("2 - Para remover um elemento");
            System.out.println("3 - Para ver o elemento do início");
            System.out.println("4 - Para saber o número de elementos da fila");
            System.out.println("5 - Para testar se a fila está vazia");
            System.out.println("6 - Para imprimir a fila");
            System.out.println("7 - Para sair da aplicação");
            
            opcao = entrada.nextInt();
            
            switch(opcao) {
                case 1:
                    System.out.println("Digite dado para ser enfilado:");
                    f.enqueue(entrada.nextInt());
                    break;
                case 2:
                    try {
                        System.out.println("Dado removido: " + f.dequeue());
                    }
                    catch(Exception e) {
                        System.out.println("Erro no dequeue: " + e);
                    }
                    break;
                case 3:
                    try {
                        System.out.println("Dado no início na fila: " + f.front());
                    }
                    catch(Exception e) {
                        System.out.println("Erro no front: " + e);
                    }
                    break;
                case 4:
                    System.out.println("Número de elementos da fila: " + f.size());
                    break;
                case 5:
                    if(f.isEmpty()) {
                        System.out.println("A fila está vazia.");
                    }
                    else {
                        System.out.println("A fila não está vazia.");
                    }
                    break;
                case 6:
                    System.out.println("Fila:\n\n" + f);
                    break;
                case 7:
                    System.out.println("Saindo...");
                    break;
                default:
                    System.out.println("Opção inválida");
            }
            
        } while (opcao != 7);
        
    }
    
}
