package exercicio3;

public class FilaDinamica {
    
    private No inicio;
    private No fim;
    private int qtd;
    
    public FilaDinamica() {
        inicio = null;
        fim = null;
        qtd = 0;
    }
    
    private boolean buscar(int valor) {
        No atual = inicio;
        while (atual != null) {
            if(atual.dado == valor)
                return true;
            atual = atual.prox;
        }
        return false;
    }
    
    public void enqueue(int novoElemento) {
        
        if(buscar(novoElemento)) {
            return;
        }
        
        //Criação do nó
        No novoNo = new No(novoElemento);
        //2 condições
        if(isEmpty()) {
            inicio = fim = novoNo;
        }
        else {
            fim.prox = novoNo;
            fim = novoNo;
        }
        //aumenta qtd
        qtd++;
    }
    
    public int dequeue() throws Exception {
        
        if(isEmpty()) {
            throw new Exception("Fila vazia");
        }
        else {
            No temp = inicio;
            
            if (size() == 1) {
                inicio = fim = null;
            }
            else {
                inicio = inicio.prox;
            }
            
            qtd--;
            return temp.dado;
        }
        
    }
    
    public int front() throws Exception {
        if(isEmpty()) {
            throw new Exception("Fila vazia");
        }
        else {
            return inicio.dado;
        }
    }
    
    public int size() {
        return qtd;
    }
    
    public boolean isEmpty() {
        return qtd == 0;
    }
    
    @Override
    public String toString() {
        String saida = "";
        No atual = inicio;
        while (atual != null) {
            saida += atual.dado + " ";
            atual = atual.prox;
        }
        return saida;
    }
    
}