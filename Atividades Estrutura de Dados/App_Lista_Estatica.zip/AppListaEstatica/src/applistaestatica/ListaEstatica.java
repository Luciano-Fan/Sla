package applistaestatica;

public class ListaEstatica {

    private int dados[];
    private int qtd;

    public ListaEstatica(int tamanho) {
        dados = new int[tamanho];
        qtd = 0;
    }

    public void add(int novoElemento, int posicao) throws Exception {
        if (isFull()) {
            throw new Exception("Lista cheia");
        } else if (posicao > qtd) {
            throw new Exception("Posição inválida");
        } else if (posicao == qtd) {
            dados[posicao] = novoElemento;
            qtd++;
        } else {
            for (int i = qtd; i > posicao; i--) {
                dados[i] = dados[i - 1];
            }
            dados[posicao] = novoElemento;
            qtd++;
        }
    }

    public void add(int novoElemento) throws Exception {
        add(novoElemento, qtd);
    }

    public int remove(int posicao) throws Exception {
        if (isEmpty()) {
            throw new Exception("Lista vazia");
        } else if (posicao >= qtd) {
            throw new Exception("Posição inválida");
        } else if (posicao == qtd - 1) {
            qtd--;
            return dados[qtd];
        } else {
            int temp = dados[posicao];
            for (int i = posicao; i < qtd - 1; i++) {
                dados[i] = dados[i + 1];
            }
            qtd--;
            return temp;
        }
    }

    public int get(int posicao) throws Exception {
        if (isEmpty()) {
            throw new Exception("Lista vazia");
        } else if (posicao >= qtd) {
            throw new Exception("Posição inválida");
        } else {
            return dados[posicao];
        }
    }

    public void set(int novoValor, int posicao) throws Exception {
        if (isEmpty()) {
            throw new Exception("Lista vazia");
        } else if (posicao >= qtd) {
            throw new Exception("Posição inválida");
        } else {
            dados[posicao] = novoValor;
        }
    }

    public int ultInd(int Elem) {
        int temp = -1;
        for (int i = qtd - 1; i >= 0; i--) {
            if (Elem == dados[i]) {
                temp = i;
                break;
            }
        }
        return temp;
    }

    public void trocar() throws Exception {
        int aux[] = new int[dados.length]; 
        if (isEmpty()) {
            throw new Exception("Lista vazia");
        } else {
            
            for (int i = 0; i < qtd; i++) {
                aux[i] = dados[qtd-i-1];
                
            }
            for (int i = 0; i < qtd; i++) {
                dados[i] = aux[i];
                
            }
            

        }
    }

    public void removeElem(int Element) throws Exception {
        for (int i = qtd - 1; i >= 0; i--) {
            if (Element == dados[i]) {

                remove(i);
            }

        }
    }

    public int size() {
        return qtd;
    }

    public boolean isEmpty() {
        return qtd == 0;
    }

    public boolean isFull() {
        return qtd == dados.length;
    }

    @Override
    public String toString() {
        String saida = "";
        for (int i = 0; i < qtd; i++) {
            saida += dados[i] + ", ";
        }
        return saida;
    }

}
