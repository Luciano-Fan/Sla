package applistaestatica;

import java.util.Scanner;

public class AppListaEstatica {

    public static void main(String[] args) throws Exception {

        Scanner entrada = new Scanner(System.in);

        System.out.println("Digite tamanho da lista");
        int tamanho = entrada.nextInt();
        ListaEstatica lista = new ListaEstatica(tamanho);

        int opcao, novoElemento, posicao;

        do {

            System.out.println("Digite:"
                    + "\n1 - Inserir elemento em posição escolhida"
                    + "\n2 - Inserir elemento na última posição"
                    + "\n3 - Remover um elemento em posição escolhida"
                    + "\n4 - Alterar o valor em posição escolhida"
                    + "\n5 - Obter o valor de um elemento em posição escolhida"
                    + "\n6 - Ver o número de elementos da lista"
                    + "\n7 - Ver se a lista está vazia"
                    + "\n8 - Ver se a lista está cheia"
                    + "\n9 - Imprimir"
                    + "\n10 - Sair"
                    + "\n11 - Exercício 3"
                    + "\n12 - Exercício 1"
                    + "\n13 - Exercício 2"
            );

            opcao = entrada.nextInt();

            switch (opcao) {
                case 1:
                    System.out.println("Digite o valor:");
                    novoElemento = entrada.nextInt();
                    System.out.println("Digite posição:");
                    posicao = entrada.nextInt();
                    try {
                        lista.add(novoElemento, posicao);
                    } catch (Exception e) {
                        System.out.println(e);
                    }
                    break;
                case 2:
                    System.out.println("Digite o valor:");
                    novoElemento = entrada.nextInt();
                    try {
                        lista.add(novoElemento);
                    } catch (Exception e) {
                        System.out.println(e);
                    }
                    break;
                case 3:
                    System.out.println("Digite posição de remoção:");
                    posicao = entrada.nextInt();
                    try {
                        System.out.println("Elemento removido: " + lista.remove(posicao));
                    } catch (Exception e) {
                        System.out.println(e);
                    }
                    break;
                case 4:
                    System.out.println("Digite o novo valor:");
                    novoElemento = entrada.nextInt();
                    System.out.println("Digite a posição a ser alterada:");
                    posicao = entrada.nextInt();
                    try {
                        lista.set(novoElemento, posicao);
                    } catch (Exception e) {
                        System.out.println(e);
                    }
                    break;
                case 5:
                    System.out.println("Digite a posição que deseja ler:");
                    posicao = entrada.nextInt();
                    try {
                        System.out.println("Elemento obtido: " + lista.get(posicao));
                    } catch (Exception e) {
                        System.out.println(e);
                    }
                    break;
                case 6:
                    System.out.println("Tamanho da lista: " + lista.size());
                    break;
                case 7:
                    System.out.println("Lista vazia? " + lista.isEmpty());
                    break;
                case 8:
                    System.out.println("Lista cheia? " + lista.isFull());
                    break;
                case 9:
                    System.out.println(lista);
                    break;
                case 10:
                    System.out.println("Saindo...");
                    break;
                case 11:
                    System.out.println("Digite o elemento que deseja remover");
                    int elem = entrada.nextInt();
                    lista.removeElem(elem);
                    break;
                case 12:
                    System.out.println("Digite o elemento");
                    int elem1 = entrada.nextInt();
                    System.out.println(lista.ultInd(elem1));
                    break;
                case 13:
                    
                    lista.trocar();
                    break;
                default:
                    System.out.println("Opção inválida");

            }

        } while (opcao != 10);

    }

}
