package exercicio2;

public class PilhaDinamica {
    
    //armazena o topo da pilha
    private No topo;
    //usado para contar a quantidade de elementos
    private int qtd = 0;
    
    public PilhaDinamica() {
        //indica que nenhum elemento foi inserido ainda
        topo = null;
    }
    
    public void push(int novoElemento) {
        // cria o nó
        No novoNo = new No(novoElemento);
        // avisa ao novo nó quem está "abaixo"
        novoNo.prox = topo;
        //atualiza o topo
        topo = novoNo;
        //aumenta a quantidade de elementos armazenados na pilha
        qtd++;
    }
    
    public int pop() throws Exception{
        if(!isEmpty()) {
            //guarda temporariamente
            No temp = topo;
            // desloca o topo
            topo = topo.prox;
            //diminui a quantidade de dados armazenados
            qtd--;
            //retorna o valor armazenado anteriormente no topo
            return temp.dado;
        }
        else {
            // não há o que ser removido
            throw new Exception ("Pilha vazia");
        }
    }
    
    public int top() throws Exception{
        if(!isEmpty())
            // apenas retorna o que está armazenado no topo
            return topo.dado;
        else
            // não há p que ser removido
            throw new Exception("Pilha vazia");
    }
    
    public boolean isEmpty() {
        // se topo é nulo, não existe nenhum elemento
        return topo == null;
    }
    
    public int size() {
        //usa uma variável para contar
        return qtd;
        // se não usar variável, considerar o código comentado
//        No atual = topo;
//        int cont = 0;
//        while(atual != null) {
//            cont++;
//            atual = atual.prox;
//        }
//        return cont;
    }

    @Override
    public String toString() {
        //começa pelo topo
        No atual = topo;
        //cria uma String vazia 
        String saida = "";
        //enquanto não chegar em um elemento nulo
        while(atual != null) {
            //armazene na String o conteúdo do nó
            saida += atual.dado + ", ";
            //faça o nó atual caminhar pelos elementos
            atual = atual.prox;
        }
        // retorne a String com todos os elementos
        return saida;
    }
    
}