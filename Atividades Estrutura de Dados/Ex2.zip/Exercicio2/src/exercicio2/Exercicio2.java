package exercicio2;

public class Exercicio2 {

    public static void main(String[] args) {

        FilaDinamica f = new FilaDinamica();

        f.enqueue(73);
        f.enqueue(51);
        f.enqueue(17);

        System.out.println("Fila: " + f);
        try {
            System.out.println("Elemento removido: " + f.dequeue());

            f.enqueue(42);

            System.out.println("Fila: " + f);

            System.out.println("Tamanho da fila:" + f.size());

            while (!f.isEmpty()) {
                System.out.println("Elemento removido: " + f.dequeue());
            }

            System.out.println("Fila vazia? " + f.isEmpty());
        } catch (Exception e) {
            System.out.println(e);
        }

    }
}
