package exercicio2;

public class FilaDinamica {

    private PilhaDinamica pilhaPrincipal;
    private PilhaDinamica pilhaAuxiliar;

    public FilaDinamica() {
        pilhaPrincipal = new PilhaDinamica();
        pilhaAuxiliar = new PilhaDinamica();
    }

    public void enqueue(int novoElemento) {
        pilhaPrincipal.push(novoElemento);
    }

    public int dequeue() throws Exception {
        try {
            int t = 0;
            while (pilhaPrincipal.size() > 1) {
                pilhaAuxiliar.push(pilhaPrincipal.pop());
            }
            t = pilhaPrincipal.pop();
            while (!pilhaAuxiliar.isEmpty()) {
                pilhaPrincipal.push(pilhaAuxiliar.pop());
            }
            return t;
        } catch (Exception e) {
            throw new Exception("Fila vazia");
        }
    }

    public int front() throws Exception {
        int t = 0;
        if (isEmpty()) {
            throw new Exception("Fila vazia");
        } else {

            try {
                while (pilhaPrincipal.size() > 1) {
                    pilhaAuxiliar.push(pilhaPrincipal.pop());
                }
                t = pilhaPrincipal.top();
                while (!pilhaAuxiliar.isEmpty()) {
                    pilhaPrincipal.push(pilhaAuxiliar.pop());
                }

            } catch (Exception e) {
                System.out.println(e);
            }
        }
        return t;
    }

    public int size() {
        return pilhaPrincipal.size() + pilhaAuxiliar.size();
    }

    public boolean isEmpty() {
        if (pilhaPrincipal.size() + pilhaAuxiliar.size() > 0) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        String z = "";
        try {
            while (pilhaPrincipal.size() > 1) {
                pilhaAuxiliar.push(pilhaPrincipal.pop());
            }
            while (!pilhaAuxiliar.isEmpty()) {
                pilhaPrincipal.push(pilhaAuxiliar.pop());
                z = z + " " + pilhaPrincipal.top();
            }

        } catch (Exception e) {
            System.out.println(e);
        }
        return z;
    }

}
